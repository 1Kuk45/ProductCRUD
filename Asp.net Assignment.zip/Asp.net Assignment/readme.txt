Asp.net product CRUD assignment
There are 3 folder in here
1. Db -> product table script with it sample data.
2. API -> Web API for CRUD endpoints of product.
3. Frontend -> Product CRUD view page with HTML,CSS and JS.