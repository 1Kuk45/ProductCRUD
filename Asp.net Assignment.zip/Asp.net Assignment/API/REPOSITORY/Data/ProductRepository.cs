﻿using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using MODEL;
using MODEL.Entities;
using REPOSITORY.IData;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MODEL.DTO;

namespace REPOSITORY.Data
{
    public class ProductRepository : IProductRepository
    {
        private readonly string _connectionString;
        public ProductRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<Product> GetProductById(Guid id)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = "SELECT * FROM Product WHERE PID = @PID";
            return await connection.QuerySingleOrDefaultAsync<Product>(sql, new { PID = id });
        }
        public async Task<IEnumerable<Product>> GetProducts()
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = "SELECT * FROM Product";
            return await connection.QueryAsync<Product>(sql);
        }
        public async Task AddProductRepo(Product product)
        {
            using var connection = new SqlConnection(_connectionString);
            var sql = "INSERT INTO Product (PID,ProductName,Description,Price,CreateDate) VALUES (@PID,@ProductName,@Description,@Price,@CreateDate)";
            await connection.ExecuteAsync(sql, product);
        }
        public async Task EditProductRepo(Guid id, Product product)
        {
            var sql = "UPDATE Product SET ProductName=@ProductName,Description=@Description,Price=@Price,UpdateDate=@UpdateDate,UpdateBy=@UpdateBy WHERE PID=@PID";
            using var connection = new SqlConnection(_connectionString);
            //product.UpdateDate = DateTime.Now;
            //product.UpdateBy = "Admin";
            await connection.ExecuteAsync(sql, product);
        }
        public async Task DeleteAsync(Guid id)
        {
            using var connection= new SqlConnection(_connectionString);
            var sql = "DELETE FROM Product WHERE PID=@PID";
            await connection.ExecuteAsync(sql, new {PID = id});
        }
    }
    }
