﻿using MODEL.DTO;
using MODEL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REPOSITORY.IData
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetProducts();
        Task<Product> GetProductById(Guid id);
        Task AddProductRepo(Product product);
        Task EditProductRepo(Guid id,Product product);
        Task DeleteAsync(Guid id);
    }
}
