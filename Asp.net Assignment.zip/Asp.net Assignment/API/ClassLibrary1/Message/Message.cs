﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL.Message
{
    public class Message
    {
        public const string Successfully = "Successfully";
        public const string Result = "Result Found!";
        public const string NoRecordFound = "No Record Found!";
        public const string AddProduct = "Product saved successfully.";
        public const string UpdatedProduct = "Product updated successfully.";
        public const string UpdateProductFail = "Product update failed.";
        public const string DeletedProduct = "Product deleted successfully.";
    }
}
