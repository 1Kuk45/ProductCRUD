﻿using BAL.IService;
using Microsoft.AspNetCore.Mvc;
using MODEL.DTO;
using MODEL.Entities;
using MODEL.Message;

namespace ProductCRUD.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController: ControllerBase
    {
        private readonly IProductService _service;

        public ProductController(IProductService service)
        {
            _service = service;
        }
        [HttpGet("AllProducts")]
        public async Task<IActionResult> GetAllProduct()
        {
            try
            {
                var product = await _service.GetProducts();
                if (product != null)
                {
                    return Ok(new Response { Message = Message.Result, Status = APIStatus.Successful, Data = product });
                }
                return Ok(new Response { Message = Message.NoRecordFound, Status = APIStatus.Error });
            }
            catch (Exception ex)
            {
                return Ok(new Response { Message = ex.Message, Status = APIStatus.SystemError });
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            try
            {
                var product = await _service.GetProductById(id);
                if (product != null)
                {
                    return Ok(new Response { Message = Message.Result, Status = APIStatus.Successful, Data = product });
                }
                return Ok(new Response { Message = Message.NoRecordFound, Status = APIStatus.Error });
            }
            catch (Exception ex)
            {
                return Ok(new Response { Message = ex.Message, Status = APIStatus.SystemError });
            }

        }
        [HttpPost("AddProduct")]
        public async Task<IActionResult> Add([FromBody] ProductDTO product)
        {
            await _service.AddProductService(product);
            return Ok(new Response { Message=Message.AddProduct, Status=APIStatus.Successful,Data=product});
        }
        [HttpPut("UpdateProduct")]
        public async Task<IActionResult> UpdateProduct(Guid id, [FromBody] ProductDTO product)
        {
            await _service.EditProductService(id, product);
            return Ok(new Response { Message = Message.UpdatedProduct, Status = APIStatus.Successful, Data = product });
        }
        [HttpDelete("DeleteById/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _service.DeleteAsync(id);
            return Ok(new Response { Message = Message.DeletedProduct, Status = APIStatus.Successful });
        }
    }
}
