﻿using MODEL.DTO;
using MODEL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.IService
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetProducts();
        Task<Product> GetProductById(Guid id);
        Task AddProductService(ProductDTO product);
        Task EditProductService(Guid id,ProductDTO product);
        Task DeleteAsync(Guid id);
    }
}
