﻿namespace BAL
{
    public class ServiceManager
    {

    }
}
