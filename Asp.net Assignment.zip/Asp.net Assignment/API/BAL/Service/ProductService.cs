﻿using BAL.IService;
using System;
using MODEL.Entities;
using REPOSITORY.IData;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MODEL.DTO;

namespace BAL.Service
{
    public class ProductService: IProductService
    {
        private readonly IProductRepository _repository;
        public ProductService(IProductRepository repository)
        {
            _repository = repository;
        }
        public Task<IEnumerable<Product>> GetProducts()
        {
            return _repository.GetProducts();
        }

        public Task<Product> GetProductById(Guid id)
        {
            return _repository.GetProductById(id);
        }

        public async Task AddProductService(ProductDTO product)
        {
            var model = new Product()
            {
                PID = Guid.NewGuid(),
                ProductName = product.ProductName,
                Price = product.Price,
                Description = product.Description,
                CreateDate = DateTime.Now,
                CreateBy = "Admin",

            };
            await _repository.AddProductRepo(model);
        }
        public async Task EditProductService(Guid id, ProductDTO product)
        {

            var updatedProduct = new Product
            {
                PID = id,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price,
                UpdateDate = DateTime.Now,
                UpdateBy = "Admin"
            };

            await _repository.EditProductRepo(id,updatedProduct);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
