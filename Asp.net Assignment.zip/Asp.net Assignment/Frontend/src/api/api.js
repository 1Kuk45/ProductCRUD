let modal;
let messageModal;
let editingPid = null;

document.addEventListener("DOMContentLoaded", function () {
  modal = new bootstrap.Modal(document.getElementById("productModal"));
  messageModal = new bootstrap.Modal(document.getElementById("messageModal"));
  loadProducts();
});

function showAddModal() {
  editingPid = null;
  document.getElementById("modalTitle").innerText = "Add Product";
  document.getElementById("name").value = "";
  document.getElementById("desc").value = "";
  document.getElementById("price").value = "";
  modal.show();
}
function showMessageModal(title, message, isError = false) {

  const bodyElem = document.getElementById("messageModalBody");
  bodyElem.innerText = message;
  messageModal.show();
}

async function loadProducts() {
  const res = await fetch("https://localhost:7226/api/Product/AllProducts");
  const products = await res.json();
  const table = document.getElementById("productTable");
  table.innerHTML = "";
  products.data.forEach((p, index) => {
    table.innerHTML += `<tr>
        <td>${index + 1}</td>
            <td>${p.productName}</td>
            <td>${p.description}</td>
            <td>${p.price}</td>
            <td>
                <button class='btn btn-sm btn-primary' onclick='editProduct("${
                  p.pid
                }")'>Edit</button>
                <button class='btn btn-sm btn-danger' onclick='deleteProduct("${
                  p.pid
                }")'>Delete</button>
            </td>
        </tr>`;
  });
}

async function saveProduct() {
  //const pid = document.getElementById('editingPid').value;
  const data = {
    productName: document.getElementById("name").value,
    description: document.getElementById("desc").value,
    price: document.getElementById("price").value,
  };

  try {
    if (editingPid) {
      await fetch(
        `https://localhost:7226/api/Product/UpdateProduct?id=${editingPid}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        }
      );
    } else {
      await fetch("https://localhost:7226/api/Product/AddProduct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
    }
    modal.hide();
    loadProducts();
    document.getElementById("messageModalBody").innerText =
      "Product saved successfully";
    messageModal.show();
  } catch (error) {
    document.getElementById("messageModalBody").innerText =
      "Failed to save product.";
    messageModal.show();
  }
}

async function editProduct(pid) {
  const res = await fetch(`https://localhost:7226/api/Product/${pid}`);
  const json = await res.json();
  const p = json.data;
  editingPid = pid;
  document.getElementById("modalTitle").innerText = "Edit Product";
  document.getElementById("name").value = p.productName;
  document.getElementById("desc").value = p.description;
  document.getElementById("price").value = p.price;
  modal.show();
}

async function deleteProduct(pid) {
  if (confirm("Delete this product?")) {
    try {
      await fetch(`https://localhost:7226/api/Product/DeleteById/${pid}`, {
        method: "DELETE",
      });
      loadProducts();
      document.getElementById('messageModalBody').innerText = 'Product deleted successfully!';
      messageModal.show();
    } catch (error) {
      document.getElementById('messageModalBody').innerText = 'Failed to delete product.';
      messageModal.show();
    }
  }
}

loadProducts();
